package com.lab_exam.taskmanagerapp

data class Note(val id:Int , val title:String , val content: String)


